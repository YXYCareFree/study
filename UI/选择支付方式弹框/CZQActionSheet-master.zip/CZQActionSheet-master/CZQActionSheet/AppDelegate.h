//
//  AppDelegate.h
//  CZQActionSheet
//
//  Created by 崔正清 on 16/2/1.
//  Copyright © 2016年 cuizhengqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

