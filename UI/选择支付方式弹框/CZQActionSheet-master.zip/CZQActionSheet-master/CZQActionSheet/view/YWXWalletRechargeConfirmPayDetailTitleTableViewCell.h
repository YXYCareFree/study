//
//  YWXWalletRechargeConfirmPayDetailTitleTableViewCell.h
//  10000sApp
//
//  Created by 崔正清 on 16/1/8.
//  Copyright © 2016年 Kejin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YWXWalletRechargeConfirmPayDetailTitleTableViewCell : UITableViewCell

@end
