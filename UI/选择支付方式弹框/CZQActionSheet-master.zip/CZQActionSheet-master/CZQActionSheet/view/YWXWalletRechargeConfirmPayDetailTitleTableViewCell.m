//
//  YWXWalletRechargeConfirmPayDetailTitleTableViewCell.m
//  10000sApp
//
//  Created by 崔正清 on 16/1/8.
//  Copyright © 2016年 Kejin. All rights reserved.
//

#import "YWXWalletRechargeConfirmPayDetailTitleTableViewCell.h"

@implementation YWXWalletRechargeConfirmPayDetailTitleTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
