//
//  YWXWalletRechargeConfirmPayWayTableViewCell.h
//  10000sApp
//
//  Created by 崔正清 on 16/1/8.
//  Copyright © 2016年 Kejin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YWXWalletRechargeConfirmPayWayTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *mainImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectedImageView;

@end
