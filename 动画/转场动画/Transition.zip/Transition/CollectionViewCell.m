//
//  CollectionViewCell.m
//  Transition
//
//  Created by beyondSoft on 16/8/22.
//  Copyright © 2016年 beyondSoft. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
