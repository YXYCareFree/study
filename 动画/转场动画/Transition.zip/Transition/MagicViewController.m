//
//  MagicViewController.m
//  Transition
//
//  Created by beyondSoft on 16/8/22.
//  Copyright © 2016年 beyondSoft. All rights reserved.
//

#import "MagicViewController.h"

@interface MagicViewController ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView * collectionView;

@property (nonatomic, strong) UIView * tempView;
@end

@implementation MagicViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initUI];
}

- (void)initUI{

    self.view.backgroundColor = [UIColor blackColor];

    UICollectionViewFlowLayout * flowLayout = [UICollectionViewFlowLayout new];
    flowLayout.itemSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.width);
    flowLayout.minimumLineSpacing = 0;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;

    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
    _collectionView.backgroundColor = [UIColor blackColor];
    _collectionView.pagingEnabled = YES;
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
}

@end
