//
//  FirstViewController.m
//  Transition
//
//  Created by beyondSoft on 16/8/8.
//  Copyright © 2016年 beyondSoft. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"
#import "UINavigationController+XWTransition.h"
#import "UIViewController+XWTransition.h"
#import "XWCircleSpreadAnimator.h"
#import "CollectionViewCell.h"
#import "FlowLayout.h"
#import "XWMagicMoveAnimator.h"

@interface FirstViewController ()<UICollectionViewDelegate, UICollectionViewDataSource>

@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic, strong) NSArray * dataSource;
@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.collectionView registerNib:[UINib nibWithNibName:@"CollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"cell"];

    FlowLayout * layout = [FlowLayout new];
    self.collectionView.collectionViewLayout = layout;

    [self xw_addMagicMoveEndViewGroup:@[self.view]];

}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    CollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:self.dataSource[indexPath.row]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

}

- (NSArray *)dataSource{

    if (_dataSource == nil) {
        _dataSource = @[@"1.jpg", @"2.jpg", @"3.jpg", @"4.jpg", @"5.jpg", @"6.jpg"];
    }
    return _dataSource;
}

- (IBAction)btn:(id)sender {

    SecondViewController * vc = [[SecondViewController alloc] init];

    XWCircleSpreadAnimator *animator = [XWCircleSpreadAnimator xw_animatorWithStartCenter:self.button.center radius:20];
    [self.navigationController xw_pushViewController:vc withAnimator:animator];
    //[self xw_presentViewController:vc withAnimator:animator];
}

@end
