//
//  SecondViewController.m
//  Transition
//
//  Created by beyondSoft on 16/8/8.
//  Copyright © 2016年 beyondSoft. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor grayColor];
}



@end
